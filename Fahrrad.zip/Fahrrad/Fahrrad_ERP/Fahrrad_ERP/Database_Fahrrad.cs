﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fahrrad_ERP
{
    public class Database_Fahrrad
    {
        string con_string = "SERVER=localhost; " +
                            "DATABASE=fahrrad; " +
                            "UID=root ";

        public void setData(string command)
        {
            MySqlConnection mycon = new MySqlConnection(con_string);
            MySqlCommand comm = mycon.CreateCommand();
            comm.CommandText = command;
            try
            {
                mycon.Open();
                comm.ExecuteNonQuery();
                mycon.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Die Daten konnten nicht in die Datenbank geschrieben werden. Beachten Sie die Fehlermeldung: \n\n" + e.ToString(), "Warnung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public string[,] getData(string command)
        {
            int i = 0, j = 0;
            MySqlConnection mycon = new MySqlConnection(con_string);
            MySqlCommand comm = mycon.CreateCommand();
            comm.CommandText = command;
            MySqlDataReader Reader;
            try
            {
                mycon.Open();
                Reader = comm.ExecuteReader();
                string[,] back = new string[Reader.GetSchemaTable().Rows.Count, Reader.GetSchemaTable().Columns.Count];
                while (Reader.Read())
                {
                    for (j = 0; j < Reader.FieldCount; j++)
                        back[i, j] = Reader.GetValue(j).ToString();
                    i++;
                }
                mycon.Close();
                return back;
            }
            catch (Exception e)
            {
                MessageBox.Show("Bei der Datenbank Abfrage ist ein Fehler aufgetreten. Beachten Sie die Fehlermeldung: \n\n" + e.ToString(), "Warnung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                string[,] back = new string[1,1];
                back[0, 0] = "";
                return back;
            }
        }
    }
}
