﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.Sql;
using MySql.Data.MySqlClient;

namespace Fahrrad_ERP
{
    public class Database_Fahrrad
    {
        string con_string = "SERVER=localhost; " +
                            "DATABASE=fahrrad; " +
                            "UID=root ";
        
        public void con ()
        {
            MySqlConnection mycon = new MySqlConnection(con_string);
           
            MySqlCommand comm = mycon.CreateCommand();
            comm.CommandText = "select * from kunden";
            MySqlDataReader Reader;
            mycon.Open();
            Reader = comm.ExecuteReader();
            while (Reader.Read())
            {
                string row = "";
                for (int i = 0; i < Reader.FieldCount; i++)
                    row += Reader.GetValue(i).ToString() + ", ";
                Console.WriteLine(row);
            }
            mycon.Close();
            
        }
    }
}
