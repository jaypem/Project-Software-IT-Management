﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fahrrad_ERP
{
    public class User
    {
        public static string login;
        public static string Nachname;
        public static string Name;
        public static string Abteilung;
        public static bool admin;
        public static bool ansichtL;
        public static bool ansichtV;
        public static bool ansichtW;

        public void setUserInformation(string login)
        {
            string[,] str = new string[,] { { "" } };
            string sqlcmd = "SELECT * FROM `personal` WHERE `login` LIKE '" + login + "'";
            Database_Fahrrad daten = new Database_Fahrrad();
            str = daten.getData(sqlcmd);
            User.login = str[0, 0].ToString();
            User.Nachname = str[0, 2].ToString();
            User.Name = str[0, 3].ToString();
            User.Abteilung = str[0, 4].ToString();
            if (str[0, 5] == "1") User.admin = true;
            if (str[0, 6] == "1") User.ansichtL = true;
            if (str[0, 7] == "1") User.ansichtV = true;
            if (str[0, 8] == "1") User.ansichtW = true;
            }
        }
    }
