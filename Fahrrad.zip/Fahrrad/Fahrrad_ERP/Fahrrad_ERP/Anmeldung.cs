﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fahrrad_ERP
{
    public partial class Anmeldung : Form
    {
        public Anmeldung()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (textBoxPW.Text == getPasswort(textBoxUser.Text) && getPasswort(textBoxUser.Text) != "")
            {
                this.Close();
            }
            else
            {
                MessageBox.Show("Zugriff verweigert! \n\nNutzer und Kennwort stimmen nicht überein.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxUser.Clear();
                textBoxPW.Clear();
                textBoxUser.Focus();
            }
        }

        private void buttonAB_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private string getPasswort(string user)
        {
            String pw = "";
            if (user == "root") pw = "1234";
            return pw;
        }

        private void Anmeldung_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }
    }
}