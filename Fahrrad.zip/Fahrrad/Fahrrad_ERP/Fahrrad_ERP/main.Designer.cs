﻿namespace Fahrrad_ERP
{
    partial class main
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printSetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.werkstattMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.lagerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.warenausgangToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.produktkonfiguratorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.öffnenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.einstellungenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.stammdatenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.materialstammdatenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.anlegenToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bearbeitenToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ladenMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.aufträgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produktkonfiguratorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.stammdatenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kundenstammdatenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.anlegenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bearbeitenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.verwaltungMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.lagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wareneingangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.warenausgangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rechnungswesenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aufträgeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.anlegenToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.bearbeitenToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.rechnungenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.stammdatenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kundenstammdatenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anlegenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bearbeitenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.materialstammdatenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anlegenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bearbeitenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrangeIconsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nutzerverwaltungMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.eigeneDatenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personaldatenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.passwortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.editMenu,
            this.viewMenu,
            this.werkstattMenu,
            this.ladenMenu,
            this.verwaltungMenu,
            this.windowsMenu,
            this.nutzerverwaltungMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip.Size = new System.Drawing.Size(632, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripSeparator3,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator4,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.printSetupToolStripMenuItem,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(46, 20);
            this.fileMenu.Text = "&Datei";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.newToolStripMenuItem.Text = "&Neu";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.openToolStripMenuItem.Text = "&Öffnen";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.OpenFile);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(165, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
            this.saveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.saveToolStripMenuItem.Text = "&Speichern";
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.saveAsToolStripMenuItem.Text = "Speichern &unter";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.SaveAsToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(165, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
            this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.printToolStripMenuItem.Text = "&Drucken";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.printPreviewToolStripMenuItem.Text = "&Seitenansicht";
            // 
            // printSetupToolStripMenuItem
            // 
            this.printSetupToolStripMenuItem.Name = "printSetupToolStripMenuItem";
            this.printSetupToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.printSetupToolStripMenuItem.Text = "Druckeinrichtung";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(165, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.exitToolStripMenuItem.Text = "&Beenden";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolsStripMenuItem_Click);
            // 
            // editMenu
            // 
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator6,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator7,
            this.selectAllToolStripMenuItem});
            this.editMenu.Name = "editMenu";
            this.editMenu.Size = new System.Drawing.Size(75, 20);
            this.editMenu.Text = "&Bearbeiten";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("undoToolStripMenuItem.Image")));
            this.undoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.undoToolStripMenuItem.Text = "&Rückgängig";
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("redoToolStripMenuItem.Image")));
            this.redoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.redoToolStripMenuItem.Text = "&Wiederholen";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(194, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.cutToolStripMenuItem.Text = "&Ausschneiden";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.CutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
            this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyToolStripMenuItem.Text = "&Kopieren";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.CopyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
            this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.pasteToolStripMenuItem.Text = "&Einfügen";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.PasteToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(194, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.selectAllToolStripMenuItem.Text = "&Alle auswählen";
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolBarToolStripMenuItem,
            this.statusBarToolStripMenuItem});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(59, 20);
            this.viewMenu.Text = "&Ansicht";
            // 
            // toolBarToolStripMenuItem
            // 
            this.toolBarToolStripMenuItem.Checked = true;
            this.toolBarToolStripMenuItem.CheckOnClick = true;
            this.toolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolBarToolStripMenuItem.Name = "toolBarToolStripMenuItem";
            this.toolBarToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.toolBarToolStripMenuItem.Text = "&Symbolleiste";
            this.toolBarToolStripMenuItem.Click += new System.EventHandler(this.ToolBarToolStripMenuItem_Click);
            // 
            // statusBarToolStripMenuItem
            // 
            this.statusBarToolStripMenuItem.Checked = true;
            this.statusBarToolStripMenuItem.CheckOnClick = true;
            this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
            this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.statusBarToolStripMenuItem.Text = "Status&leiste";
            this.statusBarToolStripMenuItem.Click += new System.EventHandler(this.StatusBarToolStripMenuItem_Click);
            // 
            // werkstattMenu
            // 
            this.werkstattMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lagerToolStripMenuItem1,
            this.produktkonfiguratorToolStripMenuItem1,
            this.toolStripSeparator12,
            this.stammdatenToolStripMenuItem2});
            this.werkstattMenu.Name = "werkstattMenu";
            this.werkstattMenu.Size = new System.Drawing.Size(69, 20);
            this.werkstattMenu.Text = "&Werkstatt";
            // 
            // lagerToolStripMenuItem1
            // 
            this.lagerToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.warenausgangToolStripMenuItem1});
            this.lagerToolStripMenuItem1.Name = "lagerToolStripMenuItem1";
            this.lagerToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.lagerToolStripMenuItem1.Text = "&Lager";
            // 
            // warenausgangToolStripMenuItem1
            // 
            this.warenausgangToolStripMenuItem1.Name = "warenausgangToolStripMenuItem1";
            this.warenausgangToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.warenausgangToolStripMenuItem1.Text = "&Warenausgang";
            // 
            // produktkonfiguratorToolStripMenuItem1
            // 
            this.produktkonfiguratorToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öffnenToolStripMenuItem,
            this.toolStripSeparator11,
            this.einstellungenToolStripMenuItem});
            this.produktkonfiguratorToolStripMenuItem1.Name = "produktkonfiguratorToolStripMenuItem1";
            this.produktkonfiguratorToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.produktkonfiguratorToolStripMenuItem1.Text = "&Produktkonfigurator";
            // 
            // öffnenToolStripMenuItem
            // 
            this.öffnenToolStripMenuItem.Name = "öffnenToolStripMenuItem";
            this.öffnenToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.öffnenToolStripMenuItem.Text = "Öffnen";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(142, 6);
            // 
            // einstellungenToolStripMenuItem
            // 
            this.einstellungenToolStripMenuItem.Name = "einstellungenToolStripMenuItem";
            this.einstellungenToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.einstellungenToolStripMenuItem.Text = "Einstellungen";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(179, 6);
            // 
            // stammdatenToolStripMenuItem2
            // 
            this.stammdatenToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.materialstammdatenToolStripMenuItem1});
            this.stammdatenToolStripMenuItem2.Name = "stammdatenToolStripMenuItem2";
            this.stammdatenToolStripMenuItem2.Size = new System.Drawing.Size(182, 22);
            this.stammdatenToolStripMenuItem2.Text = "&Stammdaten";
            // 
            // materialstammdatenToolStripMenuItem1
            // 
            this.materialstammdatenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anlegenToolStripMenuItem3,
            this.bearbeitenToolStripMenuItem3});
            this.materialstammdatenToolStripMenuItem1.Name = "materialstammdatenToolStripMenuItem1";
            this.materialstammdatenToolStripMenuItem1.Size = new System.Drawing.Size(184, 22);
            this.materialstammdatenToolStripMenuItem1.Text = "&Materialstammdaten";
            // 
            // anlegenToolStripMenuItem3
            // 
            this.anlegenToolStripMenuItem3.Name = "anlegenToolStripMenuItem3";
            this.anlegenToolStripMenuItem3.Size = new System.Drawing.Size(130, 22);
            this.anlegenToolStripMenuItem3.Text = "&Anlegen";
            // 
            // bearbeitenToolStripMenuItem3
            // 
            this.bearbeitenToolStripMenuItem3.Name = "bearbeitenToolStripMenuItem3";
            this.bearbeitenToolStripMenuItem3.Size = new System.Drawing.Size(130, 22);
            this.bearbeitenToolStripMenuItem3.Text = "&Bearbeiten";
            // 
            // ladenMenu
            // 
            this.ladenMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aufträgeToolStripMenuItem,
            this.produktkonfiguratorToolStripMenuItem,
            this.toolStripSeparator10,
            this.stammdatenToolStripMenuItem1});
            this.ladenMenu.Name = "ladenMenu";
            this.ladenMenu.Size = new System.Drawing.Size(51, 20);
            this.ladenMenu.Text = "&Laden";
            // 
            // aufträgeToolStripMenuItem
            // 
            this.aufträgeToolStripMenuItem.Name = "aufträgeToolStripMenuItem";
            this.aufträgeToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.aufträgeToolStripMenuItem.Text = "&Aufträge";
            // 
            // produktkonfiguratorToolStripMenuItem
            // 
            this.produktkonfiguratorToolStripMenuItem.Name = "produktkonfiguratorToolStripMenuItem";
            this.produktkonfiguratorToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.produktkonfiguratorToolStripMenuItem.Text = "&Produktkonfigurator";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(179, 6);
            // 
            // stammdatenToolStripMenuItem1
            // 
            this.stammdatenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kundenstammdatenToolStripMenuItem1});
            this.stammdatenToolStripMenuItem1.Name = "stammdatenToolStripMenuItem1";
            this.stammdatenToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.stammdatenToolStripMenuItem1.Text = "&Stammdaten";
            // 
            // kundenstammdatenToolStripMenuItem1
            // 
            this.kundenstammdatenToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anlegenToolStripMenuItem2,
            this.bearbeitenToolStripMenuItem2});
            this.kundenstammdatenToolStripMenuItem1.Name = "kundenstammdatenToolStripMenuItem1";
            this.kundenstammdatenToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.kundenstammdatenToolStripMenuItem1.Text = "&Kundenstammdaten";
            // 
            // anlegenToolStripMenuItem2
            // 
            this.anlegenToolStripMenuItem2.Name = "anlegenToolStripMenuItem2";
            this.anlegenToolStripMenuItem2.Size = new System.Drawing.Size(130, 22);
            this.anlegenToolStripMenuItem2.Text = "&Anlegen";
            // 
            // bearbeitenToolStripMenuItem2
            // 
            this.bearbeitenToolStripMenuItem2.Name = "bearbeitenToolStripMenuItem2";
            this.bearbeitenToolStripMenuItem2.Size = new System.Drawing.Size(130, 22);
            this.bearbeitenToolStripMenuItem2.Text = "&Bearbeiten";
            // 
            // verwaltungMenu
            // 
            this.verwaltungMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lagerToolStripMenuItem,
            this.rechnungswesenToolStripMenuItem,
            this.toolStripSeparator9,
            this.stammdatenToolStripMenuItem});
            this.verwaltungMenu.Name = "verwaltungMenu";
            this.verwaltungMenu.Size = new System.Drawing.Size(79, 20);
            this.verwaltungMenu.Text = "&Verwaltung";
            // 
            // lagerToolStripMenuItem
            // 
            this.lagerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wareneingangToolStripMenuItem,
            this.warenausgangToolStripMenuItem});
            this.lagerToolStripMenuItem.Name = "lagerToolStripMenuItem";
            this.lagerToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.lagerToolStripMenuItem.Text = "&Lager";
            // 
            // wareneingangToolStripMenuItem
            // 
            this.wareneingangToolStripMenuItem.Name = "wareneingangToolStripMenuItem";
            this.wareneingangToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.wareneingangToolStripMenuItem.Text = "Waren&eingang";
            // 
            // warenausgangToolStripMenuItem
            // 
            this.warenausgangToolStripMenuItem.Name = "warenausgangToolStripMenuItem";
            this.warenausgangToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.warenausgangToolStripMenuItem.Text = "Waren&ausgang";
            // 
            // rechnungswesenToolStripMenuItem
            // 
            this.rechnungswesenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aufträgeToolStripMenuItem1,
            this.rechnungenToolStripMenuItem});
            this.rechnungswesenToolStripMenuItem.Name = "rechnungswesenToolStripMenuItem";
            this.rechnungswesenToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.rechnungswesenToolStripMenuItem.Text = "&Rechnungswesen";
            // 
            // aufträgeToolStripMenuItem1
            // 
            this.aufträgeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anlegenToolStripMenuItem4,
            this.bearbeitenToolStripMenuItem4});
            this.aufträgeToolStripMenuItem1.Name = "aufträgeToolStripMenuItem1";
            this.aufträgeToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.aufträgeToolStripMenuItem1.Text = "&Aufträge";
            // 
            // anlegenToolStripMenuItem4
            // 
            this.anlegenToolStripMenuItem4.Name = "anlegenToolStripMenuItem4";
            this.anlegenToolStripMenuItem4.Size = new System.Drawing.Size(130, 22);
            this.anlegenToolStripMenuItem4.Text = "&Anlegen";
            // 
            // bearbeitenToolStripMenuItem4
            // 
            this.bearbeitenToolStripMenuItem4.Name = "bearbeitenToolStripMenuItem4";
            this.bearbeitenToolStripMenuItem4.Size = new System.Drawing.Size(130, 22);
            this.bearbeitenToolStripMenuItem4.Text = "&Bearbeiten";
            // 
            // rechnungenToolStripMenuItem
            // 
            this.rechnungenToolStripMenuItem.Name = "rechnungenToolStripMenuItem";
            this.rechnungenToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.rechnungenToolStripMenuItem.Text = "&Rechnungen";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(163, 6);
            // 
            // stammdatenToolStripMenuItem
            // 
            this.stammdatenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kundenstammdatenToolStripMenuItem,
            this.materialstammdatenToolStripMenuItem});
            this.stammdatenToolStripMenuItem.Name = "stammdatenToolStripMenuItem";
            this.stammdatenToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.stammdatenToolStripMenuItem.Text = "&Stammdaten";
            // 
            // kundenstammdatenToolStripMenuItem
            // 
            this.kundenstammdatenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anlegenToolStripMenuItem,
            this.bearbeitenToolStripMenuItem});
            this.kundenstammdatenToolStripMenuItem.Name = "kundenstammdatenToolStripMenuItem";
            this.kundenstammdatenToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.kundenstammdatenToolStripMenuItem.Text = "&Kundenstammdaten";
            // 
            // anlegenToolStripMenuItem
            // 
            this.anlegenToolStripMenuItem.Name = "anlegenToolStripMenuItem";
            this.anlegenToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.anlegenToolStripMenuItem.Text = "&Anlegen";
            // 
            // bearbeitenToolStripMenuItem
            // 
            this.bearbeitenToolStripMenuItem.Name = "bearbeitenToolStripMenuItem";
            this.bearbeitenToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.bearbeitenToolStripMenuItem.Text = "&Bearbeiten";
            // 
            // materialstammdatenToolStripMenuItem
            // 
            this.materialstammdatenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anlegenToolStripMenuItem1,
            this.bearbeitenToolStripMenuItem1});
            this.materialstammdatenToolStripMenuItem.Name = "materialstammdatenToolStripMenuItem";
            this.materialstammdatenToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.materialstammdatenToolStripMenuItem.Text = "&Materialstammdaten";
            // 
            // anlegenToolStripMenuItem1
            // 
            this.anlegenToolStripMenuItem1.Name = "anlegenToolStripMenuItem1";
            this.anlegenToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.anlegenToolStripMenuItem1.Text = "&Anlegen";
            // 
            // bearbeitenToolStripMenuItem1
            // 
            this.bearbeitenToolStripMenuItem1.Name = "bearbeitenToolStripMenuItem1";
            this.bearbeitenToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.bearbeitenToolStripMenuItem1.Text = "&Bearbeiten";
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cascadeToolStripMenuItem,
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.closeAllToolStripMenuItem,
            this.arrangeIconsToolStripMenuItem});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(57, 20);
            this.windowsMenu.Text = "&Fenster";
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.cascadeToolStripMenuItem.Text = "Ü&berlappend";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.CascadeToolStripMenuItem_Click);
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.tileVerticalToolStripMenuItem.Text = "&Nebeneinander";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.TileVerticalToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.tileHorizontalToolStripMenuItem.Text = "&Untereinander";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
            // 
            // closeAllToolStripMenuItem
            // 
            this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
            this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.closeAllToolStripMenuItem.Text = "&Alle schließen";
            this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
            // 
            // arrangeIconsToolStripMenuItem
            // 
            this.arrangeIconsToolStripMenuItem.Name = "arrangeIconsToolStripMenuItem";
            this.arrangeIconsToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.arrangeIconsToolStripMenuItem.Text = "Symbole &anordnen";
            this.arrangeIconsToolStripMenuItem.Click += new System.EventHandler(this.ArrangeIconsToolStripMenuItem_Click);
            // 
            // nutzerverwaltungMenu
            // 
            this.nutzerverwaltungMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eigeneDatenToolStripMenuItem,
            this.personaldatenToolStripMenuItem,
            this.toolStripSeparator8,
            this.passwortToolStripMenuItem});
            this.nutzerverwaltungMenu.Name = "nutzerverwaltungMenu";
            this.nutzerverwaltungMenu.Size = new System.Drawing.Size(113, 20);
            this.nutzerverwaltungMenu.Text = "&Nutzerverwaltung";
            // 
            // eigeneDatenToolStripMenuItem
            // 
            this.eigeneDatenToolStripMenuItem.Name = "eigeneDatenToolStripMenuItem";
            this.eigeneDatenToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.eigeneDatenToolStripMenuItem.Text = "Eigene &Daten";
            this.eigeneDatenToolStripMenuItem.Click += new System.EventHandler(this.eigeneDatenToolStripMenuItem_Click);
            // 
            // personaldatenToolStripMenuItem
            // 
            this.personaldatenToolStripMenuItem.Name = "personaldatenToolStripMenuItem";
            this.personaldatenToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.personaldatenToolStripMenuItem.Text = "Perso&naldaten";
            this.personaldatenToolStripMenuItem.Click += new System.EventHandler(this.personaldatenToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(146, 6);
            // 
            // passwortToolStripMenuItem
            // 
            this.passwortToolStripMenuItem.Name = "passwortToolStripMenuItem";
            this.passwortToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.passwortToolStripMenuItem.Text = "&Passwort";
            this.passwortToolStripMenuItem.Click += new System.EventHandler(this.passwortToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(632, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "main";
            this.Text = "Mein schöner Fahrradladen";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.Load += new System.EventHandler(this.main_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem printSetupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem toolBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrangeIconsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nutzerverwaltungMenu;
        private System.Windows.Forms.ToolStripMenuItem eigeneDatenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem werkstattMenu;
        private System.Windows.Forms.ToolStripMenuItem ladenMenu;
        private System.Windows.Forms.ToolStripMenuItem verwaltungMenu;
        private System.Windows.Forms.ToolStripMenuItem lagerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem warenausgangToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem produktkonfiguratorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem öffnenToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem einstellungenToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem stammdatenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem materialstammdatenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem anlegenToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bearbeitenToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem aufträgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produktkonfiguratorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem stammdatenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kundenstammdatenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem anlegenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bearbeitenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem lagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wareneingangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem warenausgangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rechnungswesenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aufträgeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem anlegenToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem bearbeitenToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem rechnungenToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem stammdatenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kundenstammdatenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anlegenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bearbeitenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem materialstammdatenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anlegenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bearbeitenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem personaldatenToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
    }
}



